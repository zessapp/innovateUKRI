import Head from 'next/head'
import Link from 'next/link'
const axios = require('axios').default;
import styled from 'styled-components';
import React, { useState } from 'react';
import useSWR from 'swr'
import { useRouter } from 'next/router'
import {UserProvider} from '../components/UserContext';

//import {UserContext, UserContextDiet} from '../components/UserContext';

import router from 'next/router';
const Button1 = styled.button`
  background-color: black;
  color: white;
  font-size: 20px;
  padding: 10px 60px;
  border-radius: 5px;
  margin: 10px 400px;
  cursor: pointer;
`;

const Button2 = Button1 
const Button3 = Button1
const Button4 = Button1
const Button5 = Button1

const Button6 = styled.button`
  background-color: green;
  color: white;
  font-size: 20px;
  padding: 10px 30px;
  border-radius: 500px;
  margin: 60px 1000px;
  cursor: pointer;
`;

const fetcher = (url) => fetch(url).then((res) => res.json());


export default function Home({Component}) {
  
  const [diet, setDiet] = useState(null);
  
  
  const router = useRouter()
  return (
      

      <h1 className="title">
        <div>
          <p> Select diet: {diet}</p>
          <Button1 onClick={() => setDiet(diet + ', ' + 'Vegan')}>Vegan</Button1>
          <Button2 onClick={() => setDiet(diet + ', ' + 'Vegeterian')}>Vegeterian</Button2>
          <Button3 onClick={() => setDiet(diet + ', ' + 'Pescetarian')}>Pescetarian</Button3>
          <Button4 onClick={() => setDiet(diet + ', ' + 'Low Carb Carnivorous')}>Low card Carnivorous</Button4>
          <Button5 onClick={() => setDiet(diet + ', ' + 'No Requirements')}>No Requirements</Button5>
          <Button6 onClick={() => router.push('http://localhost:3000/allergies')}>Next Page</Button6>

          <UserProvider value={diet}>
            <Component {...componentProps} />
          </UserProvider>
        </div>
      </h1> 

      
      

  )

  }

  

