import React from "react";
import useSWR from "swr";

const fetcher = (url) => fetch(url).then((res) => res.json());

export default function App() {
  const { data, error } = useSWR(
    "http://localhost:3000",
    {fetcher}
  );

  if (error) return error;
  if (!data) return "Loading...";
  return (
    <div>
      <h1>{data.name}</h1>
    </div>
  );
}