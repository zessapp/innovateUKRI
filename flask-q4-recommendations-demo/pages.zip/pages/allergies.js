import Head from 'next/head'
import Link from 'next/link'
const axios = require('axios').default;
import styled from 'styled-components';
import React, { useState } from 'react';
import useSWR from 'swr'
import { useRouter } from 'next/router';
import { useContext } from 'react';
import UserContext from '../components/UserContext';
import {useUserContext} from '../components/UserContext';

const Button1 = styled.button`
  background-color: black;
  color: white;
  font-size: 20px;
  padding: 10px 60px;
  border-radius: 5px;
  margin: 10px 400px;
  cursor: pointer;
`;

import { withRouter } from 'next/router'

const Button2 = Button1 
const Button3 = Button1
const Button4 = Button1
const Button5 = Button1
const Button6 = Button1

const Button7 = styled.button`
  background-color: green;
  color: white;
  font-size: 20px;
  padding: 10px 30px;
  border-radius: 500px;
  margin: 60px 1000px;
  cursor: pointer;
`;

const fetcher = (url) => fetch(url).then((res) => res.json());
const {diet} = "None"
export default function Home() {

  const [allergy, setAllergy] = useState();
  const router = useRouter();
  const menu = useMenuContext();
  return (
      
      
      <h1 className="title">
        <div>
          <p> You have selected {menu}. Select allergies: {allergy}</p>
          <Button1 onClick={() => setAllergy(allergy + ', ' + 'no allergies')}>no allergies</Button1>
          <Button2 onClick={() => setAllergy(allergy + ', ' + 'peanuts')}>peanuts</Button2>
          <Button3 onClick={() => setAllergy(allergy + ', ' + 'soya')}>soya</Button3>
          <Button4 onClick={() => setAllergy(allergy + ', ' + 'mustard')}>mustard</Button4>
          <Button5 onClick={() => setAllergy(allergy + ', ' + 'milk')}>milk</Button5>
          <Button6 onClick={() => setAllergy(allergy + ', ' + 'egg')}>egg</Button6>
          <Button7 onClick={() => router.push('http://localhost:3000/meal-planner')}>Next Page</Button7>
        </div>
        
        <style jsx global>
          {`

            .container {
              display: flex;
              flex-direction: column;
              min-height: 100vh;
            }

          `}
        </style> 
        Click <a href="http://localhost:3000">here </a> to go to back
        </h1>
  )
    
}
      

  

